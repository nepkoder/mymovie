import React from 'react';
import './NavBar.css'
import logo from './reactMovie_logo.png'
import tmdbLogo from './tmdb_logo.png'

const NavBar = (props) => {
    return (
        <div className='header'>
            <div className='left-logo'>
                <img src={logo} alt="rmdb-logo" className="rmdb-logo" />
            </div>
            <div className='right-logo'>
                <img src={tmdbLogo} alt="rmdb-logo" className="rmdb-logo" />
            </div>
        </div>
    );
};

export default NavBar;